﻿using KoreanTaxi.Data;
using KoreanTaxi.Models;
using KoreanTaxi.Models.NonDBModels;
using Microsoft.EntityFrameworkCore;
using Stripe;
using System.Security.Cryptography;
using Twilio;
using Twilio.Clients;
using Twilio.Exceptions;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Rest.Lookups.V2;
using Twilio.Rest.Trunking.V1;
using Twilio.TwiML.Voice;
using Twilio.Types;

namespace KoreanTaxi.Services
{
    public class TwilioService : ITwilioService
    {

        private readonly IConfiguration configuration;
        private readonly string SID;
        private readonly string Token;
        public TwilioService(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.SID = configuration.GetValue<string>("ConnectionStrings:twilioAccountSID");
            this.Token = configuration.GetValue<string>("ConnectionStrings:twilioAuthToken");
            TwilioClient.Init(SID, Token);

        }

        public async Task<bool> ValidatePhoneNumber(string number)
        {
            number = PhoneNumberFormat(number);
            try
            {
                var numberDetails = await PhoneNumberResource.FetchAsync(pathPhoneNumber: number);

                return numberDetails.Valid ?? false;
            }
            catch (Exception ex)
            {
            }
            return false;
        }

        public async Task<bool> SendSMS(string toNumber, string rand)
        {
            toNumber = PhoneNumberFormat(toNumber);
            string message = $"Enter Activation Code: {rand} for Hanin Taxi mobile application.";
            try
            {
                await MessageResource.CreateAsync(to: new PhoneNumber(toNumber), from: new PhoneNumber("+17707585479"), body: message);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        private string PhoneNumberFormat(string number)
        {
            return $"+1{number.Replace("-", string.Empty)}";
        }


    }
}

