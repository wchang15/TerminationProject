using KoreanTaxi;
using KoreanTaxi.Data;
using KoreanTaxi.Managers;
using KoreanTaxi.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;
using System.ComponentModel;
using System.Text;
using System.Text.Json.Serialization;
using KoreanTaxi.Hubs;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var conn = builder.Configuration.GetConnectionString("defaultString");

//builder.Services.AddControllers();
builder.Services.AddControllers().AddJsonOptions(x => x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles);
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IStripeService, StripeService>();
builder.Services.AddScoped<IBingService, BingService>();
builder.Services.AddScoped<ITwilioService, TwilioService>();
builder.Services.AddScoped<IEmailService, EmailService>();
builder.Services.AddScoped<ITollService, TollService>();
builder.Services.AddScoped<IGoogleService, GoogleService>();
builder.Services.AddScoped<TaxiHub>();
builder.Services.AddHttpClient<ITollService, TollService>(client =>
{
    client.BaseAddress = new Uri("https://api.tollguru.com/v1/origin-destination-waypoints");
});
builder.Services.AddHttpClient<IGoogleService, GoogleService>();
builder.Services.AddScoped<TripManager>();
builder.Services.AddScoped<CustomerManager>();
builder.Services.AddScoped<DriverManager>();
builder.Services.AddScoped<LoginManager>();
builder.Services.AddScoped<CompanyManager>();
builder.Services.AddScoped<BackgroundManager>();
builder.Services.AddScoped<HubManager>();
builder.Services.AddHostedService<BackgroundWorkerServiceCustomerQueue>();
builder.Services.AddHostedService<BackgroundWorkerServiceMatching>();
builder.Services.AddHostedService<BackgroundWorkerServiceRefund>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Description = "Standard Authorization header using the Bearer scheme (\"bearer {token}\")",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });

    options.OperationFilter<SecurityRequirementsOperationFilter>();
});
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8
                .GetBytes(builder.Configuration.GetSection("AppSettings:Token").Value)),
            ValidateIssuer = false,
            ValidateAudience = false
        };
    });

//builder.Services.AddCors(options => options.AddPolicy(name: "NgOrigins",
//    builder =>
//    {
//        builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
//    }));

//builder.Services.AddCors(options =>
//{
//    options.AddPolicy("AllowAll",
//        builder =>
//        {
//            builder
//            .AllowAnyOrigin()
//            .AllowAnyMethod()
//            .AllowAnyHeader();
//        });
//});

builder.Services.AddCors(options => options.AddPolicy(name: "corsapp", policy =>
{
    policy.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
}));

builder.Services.AddDbContext<TaxiDbContext>(options => options.UseNpgsql(conn).UseLowerCaseNamingConvention());

//builder.Services.AddDbContext<TaxiDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("defaultString")));
//builder.Services.AddDbContext<TaxiDbContext>(options => options.UseLazyLoadingProxies().UseSqlServer(builder.Configuration.GetConnectionString("defaultString")));

builder.Services.AddSignalR(e =>
{
    e.MaximumReceiveMessageSize = 102400000;
    e.KeepAliveInterval = TimeSpan.FromMinutes(5);
    e.ClientTimeoutInterval = TimeSpan.FromMinutes(10);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
// if (app.Environment.IsDevelopment())
// {

app.UseSwaggerAuthorized();
app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "SecureSwagger v1"));
// }
app.UseRouting();

app.UseCors("corsapp");



app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.MapHub<TaxiHub>("/Taxi");

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;

    var context = services.GetRequiredService<TaxiDbContext>();
    if (context.Database.GetPendingMigrations().Any())
    {
        context.Database.Migrate();
    }
}

app.Run();
