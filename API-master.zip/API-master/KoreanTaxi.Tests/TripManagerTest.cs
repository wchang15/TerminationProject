﻿//using KoreanTaxi.Data;
//using KoreanTaxi.Managers;
//using KoreanTaxi.Models.Enums;
//using KoreanTaxi.Models;
//using Moq;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Moq.EntityFrameworkCore;
//using KoreanTaxi.Models.NonDBModels;

//namespace KoreanTaxi.Tests
//{
//    [TestClass]
//    public class TripManagerTest
//    {
//        private Mock<TaxiDbContext> _mockCtx = new Mock<TaxiDbContext>();
//        private List<Company> companies;
//        private List<Customer> customers;
//        private List<LoginUser> loginUsers;
//        private List<Driver> drivers;
//        private List<DriverQueue> driverQueues;
//        private List<GoogleLocation> googleLocations;
//        private List<Trip> trips;
//        private List<CustomerQueue> customerQueues;
//        private List<Payment> payments;

//        [TestInitialize]
//        public void Initiailize()
//        {
//            companies = new List<Company>() {
//                new Company { CompanyID = 1, Name="", ContactName="", PhoneNumber= ""}
//            };
//            customers = new List<Customer> {
//                new Customer { CustomerID = 1, FirstName = "TestFirstName1", LastName = "TestLastName1", PhoneNumber = "201-856-7857", LoginUserID = 1, StripeCustomerID = "TestStripeID1", IsVerified = true },
//                new Customer { CustomerID = 2, FirstName = "TestFirstName2", LastName = "TestLastName2", PhoneNumber = "201-856-1234", LoginUserID = 2, StripeCustomerID = "TestStripeID2", IsVerified = true },
//                new Customer { CustomerID = 3, FirstName = "TestFirstName3", LastName = "TestLastName3", PhoneNumber = "201-856-1235", LoginUserID = 3, StripeCustomerID = "TestStripeID3", IsVerified = false }
//            };
//            loginUsers = new List<LoginUser> {
//                new LoginUser { LoginUserID = 1, Username = "TestUserName1", Role = EnumUserRole.CUSTOMER, RefreshToken = "refresh", TokenCreated = DateTime.UtcNow, TokenExpires = DateTime.UtcNow },
//                new LoginUser { LoginUserID = 2, Username = "TestUserName2", Role = EnumUserRole.CUSTOMER },
//                new LoginUser { LoginUserID = 3, Username = "TestUserName3", Role = EnumUserRole.CUSTOMER },
//                new LoginUser { LoginUserID = 4, Username = "TestUserName4", Role = EnumUserRole.DRIVER, RefreshToken = "refresh", TokenCreated = DateTime.UtcNow, TokenExpires = DateTime.UtcNow },
//                new LoginUser { LoginUserID = 5, Username = "TestUserName5", Role = EnumUserRole.DRIVER },
//                new LoginUser { LoginUserID = 6, Username = "TestUserName6", Role = EnumUserRole.DRIVER },
//            };
//            drivers = new List<Driver> {
//                new Driver {DriverID = 1, FirstName ="TestDriverFirstName1", LastName="TestDriverLastName1", PhoneNumber="1234567", CompanyID = 1, LoginUserID = 4},
//                new Driver {DriverID = 2, FirstName ="TestDriverFirstName2", LastName="TestDriverLastName2", PhoneNumber="1234567", CompanyID = 1, LoginUserID = 5},
//                new Driver {DriverID = 3, FirstName ="TestDriverFirstName3", LastName="TestDriverLastName3", PhoneNumber="1234567", CompanyID = 1, LoginUserID = 6},
//            };
//            driverQueues = new List<DriverQueue> {
//                new DriverQueue {DriverQueueID = 1, DriverID = 1 }
//            };
//            googleLocations = new List<GoogleLocation>
//            {
//                new GoogleLocation {GoogleLocationID = 1, Name="TestName1", Address="TestAddress1", Longitude=1.0, Latitude=1.0},
//                new GoogleLocation {GoogleLocationID = 2, Name="TestName2", Address="TestAddress2", Longitude=1.0, Latitude=1.0}
//            };
//            customerQueues = new List<CustomerQueue>
//            {
//                new CustomerQueue {CustomerQueueID = 1, CustomerID = 2, TripID = 1, QueueStatus = EnumQueueStatus.WAITING}
//            };
//            trips = new List<Trip>
//            {
//                new Trip {TripID = 1, CustomerID = 2, PickupLocationID = 1, DropoffLocationID = 2, TripStatus=EnumTripStatus.MATCHING, TripType=EnumTripType.CARD},
//                new Trip {TripID = 2, CustomerID = 3, PickupLocationID = 2, DropoffLocationID = 1, TripStatus=EnumTripStatus.CUSTOMERSEARCHING, TripType=EnumTripType.CARD},
//                new Trip {TripID = 3, CustomerID = 3, DriverID = 1, PickupLocationID = 2, DropoffLocationID = 1, TripStatus=EnumTripStatus.COMPLETED, CompletedTime = DateTime.UtcNow.AddMinutes(-5) , TripType=EnumTripType.CARD}, 
//                new Trip {TripID = 4, CustomerID = 1, DriverID = 1, PickupLocationID = 2, DropoffLocationID = 1, TripStatus=EnumTripStatus.COMPLETED, CompletedTime = DateTime.UtcNow.AddMinutes(-5) , TripType=EnumTripType.CARD}, 
//                new Trip {TripID = 5, CustomerID = 2, DriverID = 2, PickupLocationID = 2, DropoffLocationID = 1, TripStatus=EnumTripStatus.COMPLETED, CompletedTime = DateTime.UtcNow.AddMinutes(-5), TripType=EnumTripType.CARD } 
//            };
//            payments = new List<Payment>
//            {
//                new Payment {PaymentID = 1, TripID = 3, PaymentStatus = EnumPaymentStatus.PAID},
//                new Payment {PaymentID = 2, TripID = 4, PaymentStatus = EnumPaymentStatus.PAID},
//                new Payment {PaymentID = 3, TripID = 5, PaymentStatus = EnumPaymentStatus.PAID}
//            };

//            foreach (var trip in trips)
//            {
//                trip.Payment = payments.Where(x => x.TripID == trip.TripID).FirstOrDefault();
//            }
//            _mockCtx.Setup(x => x.Customers).ReturnsDbSet(customers);
//            _mockCtx.Setup(x => x.LoginUsers).ReturnsDbSet(loginUsers);
//            _mockCtx.Setup(x => x.DriverQueues).ReturnsDbSet(driverQueues);
//            _mockCtx.Setup(x => x.Drivers).ReturnsDbSet(drivers);
//            _mockCtx.Setup(x => x.Companies).ReturnsDbSet(companies);
//            _mockCtx.Setup(x => x.Trips).ReturnsDbSet(trips);
//            _mockCtx.Setup(x => x.Payments).ReturnsDbSet(payments);
//            _mockCtx.Setup(x => x.CustomerQueues).ReturnsDbSet(customerQueues);
//            _mockCtx.Setup(x => x.GoogleLocations).ReturnsDbSet(googleLocations);

//        }

//        private TripManager CreateMgr()
//        {
//            return new TripManager(_mockCtx.Object);
//        }

//        [TestMethod]
//        public async Task TestGetGoogleLocation_Create()
//        {
//            var test = CreateMgr();

//            var googleLocation = await test.GetGoogleLocation("CreateAddress", "CreateName", 1.0, 1.0);

//            Assert.IsNotNull(googleLocation);
//            Assert.AreEqual(googleLocation.Name, "CreateName");
//        }

//        [TestMethod]
//        public async Task TestGetGoogleLocation_Find()
//        {
//            var test = CreateMgr();
//            var val = googleLocations.Where(x => x.GoogleLocationID == 1).FirstOrDefault();

//            var googleLocaiton = await test.GetGoogleLocation(val.Address, val.Name, val.Latitude, val.Longitude);

//            Assert.IsNotNull(googleLocaiton);
//            Assert.AreEqual(googleLocaiton.GoogleLocationID, val.GoogleLocationID);
//        }

//        [TestMethod]
//        public async Task TestGetSameTrip()
//        {
//            var test = CreateMgr();
//            var val = new Trip { PickupLocationID = 1, DropoffLocationID = 2, CustomerID = 1 };
//            var rest = trips.Where(x => x.PickupLocationID == 1 && x.DropoffLocationID == 2).FirstOrDefault();

//            var trip = await test.GetSameTrip(val);

//            Assert.IsNotNull(trip);
//            Assert.AreEqual(trip.TripID, rest.TripID);
//        }


//        [TestMethod]
//        public async Task TestGetFindFareTrip()
//        {
//            var test = CreateMgr();
//            var val = trips.Where(x => x.TripStatus == EnumTripStatus.CUSTOMERSEARCHING).FirstOrDefault();


//            var trip = await test.GetFindFareTrip(val.CustomerID, val.TripID);

//            Assert.IsNotNull(trip);
//            Assert.AreEqual(trip.TripID, val.TripID);
//        }

//        //[TestMethod]
//        //public async Task TestGetCurrentTrip()
//        //{
//        //    var test = CreateMgr();
//        //    var val = customerQueues.Where(x => x.CustomerQueueID == 1).FirstOrDefault();


//        //    var trip = await test.GetCurrentTripCustomer(val.CustomerID);

//        //    Assert.IsNotNull(trip);
//        //    Assert.AreEqual(trip.TripID, val.TripID);
//        //}

//        [TestMethod]
//        public async Task TestGetCustomerRecentTrips()
//        {
//            var test = CreateMgr();
//            var val = trips.Where(x => x.TripStatus == EnumTripStatus.COMPLETED).FirstOrDefault();
//            var count = trips.Where(x => x.TripStatus == EnumTripStatus.COMPLETED && x.CustomerID == val.CustomerID).Count();

//            var trip = await test.GetCustomerRecentTrips(val.CustomerID);

//            Assert.IsNotNull(trip);
//            Assert.AreEqual(trip.Count, count);
//        }

//        [TestMethod]
//        public async Task TestGetDriverRecentTrips()
//        {
//            var test = CreateMgr();
//            var val = trips.Where(x => x.TripStatus == EnumTripStatus.COMPLETED).FirstOrDefault();
//            var count = trips.Where(x => x.TripStatus == EnumTripStatus.COMPLETED && x.DriverID == val.DriverID).Count();


//            var trip = await test.GetDriverRecentTrips(val.DriverID.Value);

//            Assert.IsNotNull(trip);
//            Assert.AreEqual(trip.Count, count);
//        }

//    }
//}
