﻿//using KoreanTaxi.Data;
//using KoreanTaxi.Managers;
//using KoreanTaxi.Models.Enums;
//using KoreanTaxi.Models.NonDBModels;
//using KoreanTaxi.Models;
//using KoreanTaxi.Services;
//using Moq;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Moq.EntityFrameworkCore;

//namespace KoreanTaxi.Tests
//{
//    [TestClass]
//    public class DriverManagerTest
//    {
//        private Mock<TaxiDbContext> _mockCtx = new Mock<TaxiDbContext>();
//        private List<Company> companies;
//        private List<Customer> customers;
//        private List<LoginUser> loginUsers;
//        private List<Driver> drivers;
//        private List<DriverQueue> driverQueues;
//        private List<GoogleLocation> googleLocations;

//        [TestInitialize]
//        public void Initiailize()
//        {
//            companies = new List<Company>() {
//                new Company { CompanyID = 1, Name="", ContactName="", PhoneNumber= ""}
//            };
//            customers = new List<Customer> {
//                new Customer { CustomerID = 1, FirstName = "TestFirstName1", LastName = "TestLastName1", PhoneNumber = "201-856-7857", LoginUserID = 1, StripeCustomerID = "TestStripeID1", IsVerified = true },
//                new Customer { CustomerID = 2, FirstName = "TestFirstName2", LastName = "TestLastName2", PhoneNumber = "201-856-1234", LoginUserID = 2, StripeCustomerID = "TestStripeID2", IsVerified = true },
//                new Customer { CustomerID = 3, FirstName = "TestFirstName3", LastName = "TestLastName3", PhoneNumber = "201-856-1235", LoginUserID = 3, StripeCustomerID = "TestStripeID3", IsVerified = false }
//            };
//            loginUsers = new List<LoginUser> {
//                new LoginUser { LoginUserID = 1, Username = "TestUserName1", Role = EnumUserRole.CUSTOMER, RefreshToken = "refresh", TokenCreated = DateTime.UtcNow, TokenExpires = DateTime.UtcNow },
//                new LoginUser { LoginUserID = 2, Username = "TestUserName2", Role = EnumUserRole.CUSTOMER },
//                new LoginUser { LoginUserID = 3, Username = "TestUserName3", Role = EnumUserRole.CUSTOMER },
//                new LoginUser { LoginUserID = 4, Username = "TestUserName4", Role = EnumUserRole.DRIVER, RefreshToken = "refresh", TokenCreated = DateTime.UtcNow, TokenExpires = DateTime.UtcNow },
//                new LoginUser { LoginUserID = 5, Username = "TestUserName5", Role = EnumUserRole.DRIVER },
//                new LoginUser { LoginUserID = 6, Username = "TestUserName6", Role = EnumUserRole.DRIVER },
//            };
//            drivers = new List<Driver> {
//                new Driver {DriverID = 1, FirstName ="TestDriverFirstName1", LastName="TestDriverLastName1", PhoneNumber="1234567", CompanyID = 1, LoginUserID = 4},
//                new Driver {DriverID = 2, FirstName ="TestDriverFirstName2", LastName="TestDriverLastName2", PhoneNumber="1234567", CompanyID = 1, LoginUserID = 5},
//                new Driver {DriverID = 3, FirstName ="TestDriverFirstName3", LastName="TestDriverLastName3", PhoneNumber="1234567", CompanyID = 1, LoginUserID = 6},
//            };
//            driverQueues = new List<DriverQueue> {
//                new DriverQueue {DriverQueueID = 1, DriverID = 1 }
//            };
//            googleLocations = new List<GoogleLocation>
//            {
//                new GoogleLocation {GoogleLocationID = 1, Name="TestName1", Address="TestAddress1", Longitude=1.0, Latitude=1.0},
//                new GoogleLocation {GoogleLocationID = 2, Name="TestName2", Address="TestAddress2", Longitude=1.0, Latitude=1.0}
//            };
//            _mockCtx.Setup(x => x.Customers).ReturnsDbSet(customers);
//            _mockCtx.Setup(x => x.LoginUsers).ReturnsDbSet(loginUsers);
//            _mockCtx.Setup(x => x.DriverQueues).ReturnsDbSet(driverQueues);
//            _mockCtx.Setup(x => x.Drivers).ReturnsDbSet(drivers);
//            _mockCtx.Setup(x => x.Companies).ReturnsDbSet(companies);
//            _mockCtx.Setup(x => x.GoogleLocations).ReturnsDbSet(googleLocations);

//        }

//        //private DriverManager CreateMgr()
//        //{
//        //    return new DriverManager(_mockCtx.Object);
//        //}

//        [TestMethod]
//        public async Task TestGetDriverByLoginUserID()
//        {
//            var test = CreateMgr();
//            var val = drivers.Where(x => x.DriverID == 1).FirstOrDefault();

//            var driver = await test.GetDriverByLoginUserID(val.LoginUserID);

//            Assert.IsNotNull(driver);
//            Assert.AreEqual(driver.DriverID, val.DriverID);
//        }
//        //[TestMethod]
//        //public async Task TestAddDriverToQueue()
//        //{
//        //    var test = CreateMgr();
//        //    var val = drivers.Where(x => x.DriverID == 2).FirstOrDefault();

//        //    var driverQueue = await test.AddDriverToQueue(val.DriverID);

//        //    Assert.IsNotNull(driverQueue);
//        //    Assert.AreEqual(driverQueue.DriverID, val.DriverID);
//        //}
//        [TestMethod]
//        public async Task TestReAddDriverToQueue()
//        {
//            var test = CreateMgr();
//            var val = drivers.Where(x => x.DriverID == 1).FirstOrDefault();

//            var driverQueue = await test.ReAddDriverToQueue(val.DriverID);

//            Assert.IsNotNull(driverQueue);
//            Assert.AreEqual(driverQueue.DriverID, val.DriverID);
//        }
//        [TestMethod]
//        public void TestRemoveFromQueue()
//        {
//            var test = CreateMgr();
//            var val = drivers.Where(x => x.DriverID == 1).FirstOrDefault();

//            var res = test.RemoveFromQueue(val.DriverID);

//            Assert.IsNotNull(res);
//            Assert.AreEqual(res, true);
//        }
//    }
//}
