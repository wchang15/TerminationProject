﻿//using KoreanTaxi.Data;
//using KoreanTaxi.Managers;
//using KoreanTaxi.Models.Enums;
//using KoreanTaxi.Models;
//using Moq;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Moq.EntityFrameworkCore;
//using KoreanTaxi.Services;
//using Castle.Core.Configuration;
//using KoreanTaxi.Models.NonDBModels;

//namespace KoreanTaxi.Tests
//{
//    [TestClass]
//    public  class CustomerManagerTest
//    {
//        private Mock<TaxiDbContext> _mockCtx = new Mock<TaxiDbContext>();
//        private Mock<IStripeService> _mockStripe = new Mock<IStripeService>();
//        private List<Customer> customers;
//        private List<LoginUser> loginUsers;
//        private List<CustomerSavedLocation> customerSavedLocations;
//        private List<CustomerSearchHistory> customerSearchHistories;
//        private List<GoogleLocation> googleLocations;

//        [TestInitialize]
//        public void Initiailize()
//        {
//            customers = new List<Customer> {
//                new Customer { CustomerID = 1, FirstName = "TestFirstName1", LastName = "TestLastName1", PhoneNumber = "201-856-7857", LoginUserID = 1, StripeCustomerID = "TestStripeID1", IsVerified = true },
//                new Customer { CustomerID = 2, FirstName = "TestFirstName2", LastName = "TestLastName2", PhoneNumber = "201-856-1234", LoginUserID = 2, StripeCustomerID = "TestStripeID2", IsVerified = true },
//                new Customer { CustomerID = 3, FirstName = "TestFirstName3", LastName = "TestLastName3", PhoneNumber = "201-856-1235", LoginUserID = 3, StripeCustomerID = "TestStripeID3", IsVerified = false }
//            };
//            loginUsers = new List<LoginUser> {
//                new LoginUser { LoginUserID = 1, Username = "TestUserName1", Role = EnumUserRole.CUSTOMER, RefreshToken = "refresh", TokenCreated = DateTime.UtcNow, TokenExpires = DateTime.UtcNow },
//                new LoginUser { LoginUserID = 2, Username = "TestUserName2", Role = EnumUserRole.CUSTOMER },
//                new LoginUser { LoginUserID = 3, Username = "TestUserName3", Role = EnumUserRole.DRIVER },
//            };
//            customerSavedLocations = new List<CustomerSavedLocation> {
//                new CustomerSavedLocation {CustomerSavedLocationID = 1, CustomerID = 2, GoogleLocationID = 2}
//            };
//            customerSearchHistories = new List<CustomerSearchHistory> {
//                new CustomerSearchHistory {CustomerSearchHistoryID = 1, CustomerID = 2, GoogleLocationID = 2}
//            };
//            googleLocations = new List<GoogleLocation>
//            {
//                new GoogleLocation {GoogleLocationID = 1, Name="TestName1", Address="TestAddress1", Longitude=1.0, Latitude=1.0},
//                new GoogleLocation {GoogleLocationID = 2, Name="TestName2", Address="TestAddress2", Longitude=1.0, Latitude=1.0}
//            };
//            _mockCtx.Setup(x => x.Customers).ReturnsDbSet(customers);
//            _mockCtx.Setup(x => x.LoginUsers).ReturnsDbSet(loginUsers);
//            _mockCtx.Setup(x => x.CustomerSavedLocations).ReturnsDbSet(customerSavedLocations);
//            _mockCtx.Setup(x => x.CustomerSearchHistories).ReturnsDbSet(customerSearchHistories);
//            _mockCtx.Setup(x => x.GoogleLocations).ReturnsDbSet(googleLocations);
//            _mockStripe.Setup(x => x.CreateStripeCustomerAsync(It.IsAny<Customer>())).Returns(Task.FromResult("stripeID"));
//        }

//        private CustomerManager CreateMgr()
//        {
//            return new CustomerManager(_mockCtx.Object, _mockStripe.Object);
//        }

//        [TestMethod]
//        public async Task TestRegisterCustomer()
//        {
//            var test = CreateMgr();
//            var registerRequest = new RegisterRequest { Username = "test", Password = "password", FirstName = "firstname", LastName = "lastname", PhoneNumber = "123456789", Role = EnumUserRole.CUSTOMER };

//            var customer = await test.RegisterCustomer(registerRequest, 1);

//            Assert.IsNotNull(customer);
//            Assert.AreEqual(customer.FirstName, registerRequest.FirstName);
//        }

//        [TestMethod]
//        public async Task TestGetCustomerByLoginUserID()
//        {
//            var test = CreateMgr();
//            var val = customers.Where(x => x.LoginUserID == 1).FirstOrDefault();

//            var customer = await test.GetCustomerByLoginUserID(val.LoginUserID);

//            Assert.IsNotNull(customer);
//            Assert.AreEqual(customer.FirstName, val.FirstName);
//        }

//        [TestMethod]
//        public async Task TestAddStripeCustomer()
//        {
//            var test = CreateMgr();
//            var val = customers.Where(x => x.LoginUserID == 1).FirstOrDefault();

//            var stripeID = await test.AddStripeCustomer(val);

//            Assert.IsNotNull(stripeID);
//            Assert.AreEqual(stripeID, "stripeID");
//            Assert.AreEqual(val.StripeCustomerID, stripeID);
//        }

//        [TestMethod]
//        public async Task TestSaveSearchHistory()
//        {
//            var test = CreateMgr();
//            var customerVal = customers.Where(x => x.LoginUserID == 1).FirstOrDefault();
//            var googleVal = googleLocations.Where(x => x.GoogleLocationID == 1).FirstOrDefault();

//            var customerSearchHistory = await test.AddSearchHistory(customerVal.CustomerID, googleVal.GoogleLocationID); ;

//            Assert.IsNotNull(customerSearchHistory);
//            Assert.AreEqual(customerSearchHistory.CustomerID, customerVal.CustomerID);
//            Assert.AreEqual(customerSearchHistory.GoogleLocationID, googleVal.GoogleLocationID);
//        }

//        [TestMethod]
//        public async Task TestSaveLocation()
//        {
//            var test = CreateMgr();
//            var customerVal = customers.Where(x => x.LoginUserID == 1).FirstOrDefault();
//            var googleVal = googleLocations.Where(x => x.GoogleLocationID == 1).FirstOrDefault();

//            var customerSavedLocation = await test.SaveLocation(customerVal.CustomerID, googleVal.GoogleLocationID, EnumSavedLocationType.HOME);

//            Assert.IsNotNull(customerSavedLocation);
//            Assert.AreEqual(customerSavedLocation.CustomerID, customerVal.CustomerID);
//            Assert.AreEqual(customerSavedLocation.GoogleLocationID, googleVal.GoogleLocationID);
//        }
//    }
//}
