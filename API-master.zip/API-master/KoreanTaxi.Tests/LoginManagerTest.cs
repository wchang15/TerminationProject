//using BingMapsRESTToolkit;
//using KoreanTaxi.Data;
//using KoreanTaxi.Managers;
//using KoreanTaxi.Models;
//using KoreanTaxi.Models.Enums;
//using KoreanTaxi.Models.NonDBModels;
//using Microsoft.Extensions.Configuration;
//using Microsoft.VisualStudio.TestPlatform.TestHost;
//using Moq;
//using Moq.EntityFrameworkCore;

//namespace KoreanTaxi.Tests
//{
//    [TestClass]
//    public class LoginManagerTest
//    {
//        private Mock<TaxiDbContext> _mockCtx = new Mock<TaxiDbContext>();
//        private Mock<IConfiguration> _mockConfig = new Mock<IConfiguration>();
//        private List<Customer> customers;
//        private List<LoginUser> loginUsers;

//        [TestInitialize]
//        public void Initiailize()
//        {
//            customers = new List<Customer> { 
//                new Customer { CustomerID = 1, FirstName = "TestFirstName1", LastName = "TestLastName1", PhoneNumber = "201-856-7857", LoginUserID = 1, StripeCustomerID = "TestStripeID1", IsVerified = true },
//                new Customer { CustomerID = 2, FirstName = "TestFirstName2", LastName = "TestLastName2", PhoneNumber = "201-856-1234", LoginUserID = 2, StripeCustomerID = "TestStripeID2", IsVerified = true },
//                new Customer { CustomerID = 3, FirstName = "TestFirstName3", LastName = "TestLastName3", PhoneNumber = "201-856-1235", LoginUserID = 3, StripeCustomerID = "TestStripeID3", IsVerified = false }
//            };
//            loginUsers = new List<LoginUser> { 
//                new LoginUser { LoginUserID = 1, Username = "TestUserName1", Role = EnumUserRole.CUSTOMER, RefreshToken = "refresh", TokenCreated = DateTime.UtcNow, TokenExpires = DateTime.UtcNow }, 
//                new LoginUser { LoginUserID = 2, Username = "TestUserName2", Role = EnumUserRole.CUSTOMER },
//                new LoginUser { LoginUserID = 3, Username = "TestUserName3", Role = EnumUserRole.DRIVER },
//            };
//            _mockCtx.Setup(x => x.Customers).ReturnsDbSet(customers);
//            _mockCtx.Setup(x => x.LoginUsers).ReturnsDbSet(loginUsers);
//        }

//        private LoginManager CreateMgr()
//        {
//            return new LoginManager(_mockCtx.Object, _mockConfig.Object);
//        }

//        [TestMethod]
//        public async Task TestGetDriverUser()
//        {
//            var test = CreateMgr();
//            var val = loginUsers.Where(x => x.LoginUserID == 3).FirstOrDefault();

//            var loginUser = await test.GetDriverUser(val.Username);

//            Assert.IsNotNull(loginUser);
//            Assert.AreEqual(loginUser.LoginUserID, val.LoginUserID);
//        }

//        [TestMethod]
//        public async Task TestGetCustomerUser()
//        {
//            var test = CreateMgr();
//            var val = loginUsers.Where(x => x.LoginUserID == 1).FirstOrDefault();

//            var loginUser = await test.GetCustomerUser(val.Username);

//            Assert.IsNotNull(loginUser);
//            Assert.AreEqual(loginUser.LoginUserID, val.LoginUserID);
//        }

//        [TestMethod]
//        public async Task TestGetLoginUser()
//        {
//            var test = CreateMgr();
//            var val = loginUsers.Where(x => x.LoginUserID == 3).FirstOrDefault();

//            var loginUser = await test.GetLoginUser(val.LoginUserID);

//            Assert.IsNotNull(loginUser);
//            Assert.AreEqual(loginUser.Username, val.Username);
//        }

//        [TestMethod]
//        public async Task TestGetLoginUserByRefreshToken()
//        {
//            var test = CreateMgr();
//            var val = loginUsers.Where(x => x.LoginUserID == 1).FirstOrDefault();

//            var loginUser = await test.GetLoginUserByRefreshToken(val.RefreshToken);

//            Assert.IsNotNull(loginUser);
//            Assert.AreEqual(loginUser.LoginUserID, val.LoginUserID);
//        }

//        [TestMethod]
//        public async Task TestLogoutUser()
//        {
//            var test = CreateMgr();
//            var val = loginUsers.Where(x => x.LoginUserID == 1).FirstOrDefault();

//            var res = await test.LogoutUser(val);

//            Assert.IsNotNull(res);
//            Assert.AreEqual(res, true);
//            Assert.AreEqual(val.RefreshToken, null);
//        }

//        [TestMethod]
//        public async Task TestDeleteUser()
//        {
//            var test = CreateMgr();
//            var val = loginUsers.Where(x => x.LoginUserID == 1).FirstOrDefault();

//            var res = await test.DeleteUser(val);

//            Assert.IsNotNull(res);
//            Assert.AreEqual(res, true);
//            Assert.AreEqual(val.IsActive, false);
//        }

//        [TestMethod]
//        public void TestGenerateRefreshToken()
//        {
//            var test = CreateMgr();

//            var res = test.GenerateRefreshToken();

//            Assert.IsNotNull(res);
//            Assert.AreEqual(res.Token.Length > 10, true);
//        }


//        [TestMethod]
//        public async Task TestRegisterLoginUser()
//        {
//            var test = CreateMgr();
//            var registerRequest = new RegisterRequest { Username = "test", Password = "password", FirstName = "firstname", LastName = "lastname", PhoneNumber = "123456789", Role = EnumUserRole.CUSTOMER };

//            var loginUser = await test.RegisterLoginUser(registerRequest);

//            Assert.IsNotNull(loginUser);
//            Assert.AreEqual(loginUser.Username, registerRequest.Username);
//            Assert.AreEqual(loginUser.IsActive, true);
//        }
//    }
//}