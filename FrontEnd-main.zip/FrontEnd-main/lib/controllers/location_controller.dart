import 'dart:async';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';

//google maps/geo service imports
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:geocoding/geocoding.dart';
import 'package:tuple/tuple.dart';
import 'package:latlong2/latlong.dart';

//models and meta imports
import '../models/user_location.dart';
import '../services/mapbox_service.dart';
import '../utils/constants.dart';

enum EnumLocationControllerStatus { Loading, Success, Error }

/// Controls the functionality related to a user's location
class LocationController extends GetxController {
  final locationStatus = EnumLocationControllerStatus.Loading.obs;
  final isLoading = false.obs;
  final currentLocation = (null as UserLocation?).obs;
  Timer? timer;

  ////////// Getters //////////

  /// returns a formatted street address of the current user's current location
  String getCurrentAddress() => currentLocation.value?.address ?? "";

  /// returns a latitude and longitude point of the current user's current location
  LatLng getCurrentLocation() {
    if (currentLocation.value == null) return LatLng(42.8243, -73.9096);
    return LatLng(currentLocation.value!.latitude, currentLocation.value!.longitude);
  }

  /// Calculates a route from the given [src] and [dst] points
  Future<Tuple2<List<LatLng>, int>> getRoute(LatLng src, LatLng dst) async {
    List<LatLng> route = [];
    int duration = 0;
    var res = await MapBoxService.getDirection(src, dst);
    if (res.item1 != null) {
      route = res.item1!;
      duration = res.item2!;
    }

    return Tuple2(route, duration);
  }

  /// auto completes the given [text] to a set of addresses
  Future<List<UserLocation>> autoCompleteSearch(String text) async {
    return await MapBoxService.getAutoComplete(text);
  }

  ////////// Setters //////////s

  ///Get Coordinates
  Future<void> getCoordinates(UserLocation userLocation) async {
    var coordinates = await locationFromAddress("${userLocation.name}, ${userLocation.address}");
    userLocation.latitude = coordinates[0].latitude;
    userLocation.longitude = coordinates[0].longitude;
  }

  /// Attempts to retrieve the user's current location and sets location status
  Future<void> setCurrentLocation() async {
    try {
      await fetchCurrentLocation();
      locationStatus(EnumLocationControllerStatus.Success);
    } catch (e) {
      locationStatus(EnumLocationControllerStatus.Error);
    }
  }

  ////////// Helper //////////

  /// Fetches a user's current location
  Future<void> fetchCurrentLocation() async {
    try {
      Position? position;

      // validate service is enabled and location services are set
      if (await checkLocationPermission()) {
        position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high).timeout(
          const Duration(seconds: 30),
          onTimeout: () {
            throw TimeoutException("Location information could not be obtained within the requested time.");
          },
        );

        // if lng and lat is same, don't retrieve new one
        if (currentLocation.value != null) {
          if (currentLocation.value!.latitude == position.latitude &&
              currentLocation.value!.longitude == position.longitude) {
            return;
          }
        }

        List<Placemark> placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
        Placemark placeMark = placemarks[0];
        String name = placeMark.name ?? "";
        String street = placeMark.street ?? "";
        String subLocality = placeMark.subLocality ?? "";
        String locality = placeMark.locality ?? "";
        String administrativeArea = placeMark.administrativeArea ?? "";
        String postalCode = placeMark.postalCode ?? "";
        String country = placeMark.country ?? "";
        String address = "$street $locality, $administrativeArea $postalCode";

        var list = await MapBoxService.getAutoComplete(address);

        if (list.isEmpty) {
          list = await MapBoxService.getAutoComplete(street);
        }

        UserLocation loc = list[0];

        loc.latitude = position.latitude;
        loc.longitude = position.longitude;

        currentLocation(loc);

        // UserLocation? loc = await MapBoxService.getReverseGeocode(position.latitude, position.longitude);
        // loc!.latitude = position.latitude;
        // loc.longitude = position.longitude;

        // currentLocation(loc);

        // currentLocation(
        //   UserLocation(
        //       address: '$street $state, $country $zip',
        //       name: '$street',
        //       latitude: position.latitude,
        //       longitude: position.longitude,
        //       locationType: EnumLocationType.OTHER),
        // );
      } else {
        throw Exception("Location Service request has been denied!");
      }
    } on TimeoutException catch (e) {
      print('location_controller.fetchCurrentLocation');
      print(e);
      throw e;
    } catch (e) {
      print('location_controller.fetchCurrentLocation');
      print(e);
      throw e;
    }
  }

  Future<bool> checkLocationPermission() async {
    final access = await Permission.location.status;
    switch (access) {
      case PermissionStatus.denied:
      case PermissionStatus.restricted:
        final permission = await Permission.location.request();
        if (permission == PermissionStatus.granted) {
          return true;
        } else {
          return false;
        }
      case PermissionStatus.granted:
        return true;
      default:
        final permission = await Permission.location.request();
        if (permission == PermissionStatus.granted) {
          return true;
        } else {
          return false;
        }
    }
  }
}
