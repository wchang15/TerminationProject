// API address for IOS
//const String API_ADDRESS = 'https://localhost:7023/api/';

// API address for android
import 'dart:ui';

//Android dev
const String API_ADDRESS = 'https://10.0.2.2:7023/api/';
const String HUB_ADDRESS = 'https://10.0.2.2:7023/Taxi';

//Test api
// const String API_ADDRESS = 'https://koreantaxi20230502164524.azurewebsites.net/api/';
// const String HUB_ADDRESS = 'https://koreantaxi20230502164524.azurewebsites.net/Taxi';

// const String GOOGLE_API_KEY = 'AIzaSyARPrkQvIEHVaDf_RujQ-661X77ZaDJDu0';
const String GOOGLE_API_KEY = 'AIzaSyDKaH4K69Vsy_9DVNr2Sw36V_xY_ysdEVU';

const String MAPBOXAPI = 'pk.eyJ1IjoiZGFtb242MjkiLCJhIjoiY2xlNGs3bWJsMDNzdDNvbXNvMjcydXgwcCJ9.UTcz8nfh914ihTN97aCNjA';
const String STRIPEPK =
    'pk_test_51MS6oTEtVWzmXEYHdItXPRKqhfcpQUk4BX5MIfMD1eBKmayA2aTlZDPaCHBZQRo9nc0zHygkAmeATicgZUZ9pqv300rWCJtIHw';
const double MAPZOOM = 13.5;

const String TILE = 'https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png';
const String TILEAPI = 'api_key=3331bf0f-d10b-4010-beb8-a4fc8e1e68d4';

//Secure Storage
const String JWT = 'jwt';
const String REFRESH = 'refresh';
const String ID = 'id';
const String PWD = 'pwd';

//Routes
const String HOME = '/home';
const String LOGIN = '/login';
const String MAP = '/map';
const String PHOTO = '/photo';
const String CARD = '/card';
const String REGISTER = '/register';
const String PHONE = '/phone';
const String INITIAL = '/initial';
const String TRIPSETTING = '/tripsetting';
const String PAYMENTSELECT = '/paymentselect';
const String CARDADD = '/cardadd';
const String POINTADD = '/pointadd';
const String TRIP = '/trip';
const String SAVEDLOCATIONS = '/savedlocations';
const String SELECTLOCATION = '/selectlocation';
const String RATEDRIVER = '/ratedriver';
const String ADDPOINTSFROMCARD = '/addpoints';
const String DRIVERCANCEL = '/drivercancel';
const String LANGUAGE = '/language';
const String TERMS = '/terms';
const String TERM = '/term';
const String FINDIDPWD = '/findidpwd';
const String EVENT = '/event';
const String CUSTOMERSERVICE = '/customerservice';
const String TRIPHISTORY = '/triphistory';
const String PROFILE = '/profile';
const String PHONEEDIT = '/phoneedit';
const String PASSWORDEDIT = '/passwordedit';
const String SETTING = '/setting';

//Languages
const Locale KOREAN = Locale('ko', 'KR');
const Locale ENGLISH = Locale('en', 'US');
const Locale SPANISH = Locale('es', 'MX');
const String STRKOREAN = 'ko_KR';
const String STRENGLISH = 'en_US';
const String STRSPANISH = 'es_MX';

//This have to match API
const Map LANGUAGEMAP = {1: ENGLISH, 2: KOREAN, 3: SPANISH};

//Time
const int PICKUPUPDATE = 50;
const int STATUSUPDATE = 30;
const int DEBOUNCE = 300;

//TERMS

//Hub
const String HUBMATCH = "match";
const String HUBUPDATEDRIVERLOCATION = "updatedriverlocation";
const String HUBTRIPSTART = "tripstart";
const String HUBTRIPCOMPLETE = "tripcomplete";
const String HUBDRIVERCANCEL = "drivercancel";
