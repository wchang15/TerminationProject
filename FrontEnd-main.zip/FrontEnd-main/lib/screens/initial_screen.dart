import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:tax_app/controllers/customer_controller.dart';
import 'package:tax_app/controllers/location_controller.dart';
import 'package:tax_app/controllers/trip_controller.dart';
import 'package:tax_app/widgets/custom_loading_dialog.dart';

import '../utils/constants.dart';
import '../utils/image_constants.dart';

class InitialScreen extends StatefulWidget {
  const InitialScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => InitialScreenState();
}

// ignore_for_file: must_be_immutable
class InitialScreenState extends State<InitialScreen> {
  final customerController = Get.find<CustomerController>();
  final locationController = Get.find<LocationController>();
  final tripController = Get.find<TripController>();
  @override
  void initState() {
    //once(customerController.customer, (_) => Get.toNamed(HOME));
    //once(customerController.customer, (_) => Get.toNamed(LOGIN));
    once(customerController.isRefreshSuccess, (res) {
      if (res!) {
        if (customerController.customer.value!.isVerified) {
          once(locationController.currentLocation, (res) {
            once(tripController.isTripRetrieved, (res) {
              if (res) {
                if (tripController.tripStatus.value == EnumTripStatus.CUSTOMERSEARCHING ||
                    tripController.tripStatus.value == EnumTripStatus.MATCHING ||
                    tripController.tripStatus.value == EnumTripStatus.PICKINGUPCUSTOMER) {
                  Get.offNamed(HOME);
                } else if (tripController.tripStatus.value == EnumTripStatus.DRIVERCANCELED) {
                  Get.offNamed(HOME);
                  Get.toNamed(DRIVERCANCEL);
                } else {
                  Get.offNamed(HOME);
                  Get.toNamed(TRIP);
                }
              }
            });
          });
        } else {
          Get.offNamed(LOGIN);
          Get.offNamed(TERMS);
          Get.toNamed(REGISTER);
          Get.toNamed(PHONE);
        }
      } else {
        customerController.setError("");
        Get.offNamed(LOGIN);
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //This needs to be changed to a new animation
    return Scaffold(body: Lottie.asset(ImageConstant.animationOnboarding));
  }
}
