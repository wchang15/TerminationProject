//general imports
import 'dart:async';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map/plugin_api.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';

//google maps/geo service imports

//local utility imports
import 'package:tax_app/services/customer_service.dart';
import 'package:tax_app/controllers/location_controller.dart';
import 'package:tax_app/controllers/customer_controller.dart';
import 'package:tax_app/controllers/trip_controller.dart';
import 'package:tax_app/utils/icon_constants.dart';
import 'package:tax_app/utils/image_constants.dart';
import 'package:timelines/timelines.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:latlong2/latlong.dart';

//component imports
import '../services/email_service.dart';
import '../services/hub_service.dart';
import '../widgets/custom_alert.dart';
import '../widgets/custom_cancel_dialog.dart';
import '../widgets/custom_driver_card.dart';
import '../widgets/custom_svg_container.dart';
import '../widgets/custom_text_button.dart';
import '../widgets/custom_text_form_field.dart';
import '../widgets/custom_saved_location.dart';
import 'package:tax_app/widgets/custom_loading_dialog.dart';
import '../widgets/custom_tap.dart';

//metadata imports
import '../utils/constants.dart';

//style imports
import '../utils/color_constants.dart';
import '../utils/size.dart';
import '../utils/text_styles.dart';
import '../utils/validate_text.dart';

/// Home screen class
/// Home Screen is with Map (FindFare, matching, waiting Stage)
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => HomeScreenState();
}

/// Home screen components/widgets
class HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  /// class controlling a customer's metadata
  final customerController = Get.find<CustomerController>();

  /// class for accessing location functions
  final locationController = Get.find<LocationController>();

  /// class for managing trip details (src,dst)
  final tripController = Get.find<TripController>();

  /// Maintains state of nav bar
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool drawerOpen = false;

  MapController mapController = MapController();
  final mapReady = false.obs;

  var menuItemsOne = [
    ['menu_event'.tr, EVENT],
    ['menu_profile'.tr, PROFILE],
    ['menu_history'.tr, TRIPHISTORY],
    ['menu_payment'.tr, PAYMENTSELECT]
  ];

  var menuItemsTwo = [
    ['menu_customerservice'.tr, CUSTOMERSERVICE],
    ['menu_setting'.tr, SETTING]
  ];

  /// Sets the initial state of this widget
  @override
  void initState() {
    if (customerController.customer.value != null) {
      tripController.setCustomerCardID(customerController.customer.value!.defaultCardID!);
      locationController.setCurrentLocation();
    }
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (tripController.tripID.value == 0) {
        tripController.setCurrentTrip();
      }
    });
    HubService.initSignalR();
  }

  /// Event to close the side drawer
  void closeDrawer() => scaffoldKey.currentState!.openEndDrawer();

  /// Event to open the side drawer
  void openDrawer() => scaffoldKey.currentState!.openDrawer();

  void floatingActionButtonClick() => tripController.isTripSet() ? removeTrip() : openDrawer();

  void removeTrip() => tripController.removeTrip();

  var startMarkerDesign = Container(
    alignment: Alignment.center,
    decoration: BoxDecoration(color: ColorConstant.PRIMARY, borderRadius: const BorderRadius.all(Radius.circular(6))),
    child: Text('출발', style: CustomTextStyle.txtCaption2(color: ColorConstant.WHITE)),
  );
  //var startMarkerDesign = Container(child: Icon(Icons.circle, color: ColorConstant.PRIMARY));
  var arrivalMarkerDesign = Container(
    alignment: Alignment.center,
    decoration: BoxDecoration(color: ColorConstant.BLACK1, borderRadius: const BorderRadius.all(Radius.circular(6))),
    child: Text('도착', style: CustomTextStyle.txtCaption2(color: ColorConstant.WHITE)),
  );
  var circleMarker = Container(child: SvgPicture.asset(ImageConstant.imgLocation, fit: BoxFit.fill));

  List<Marker> getFlutterMarkers() {
    var markers = <Marker>[];

    var startMarker =
        Marker(width: 100, height: 100, point: tripController.getStartLatLng(), builder: (ctx) => circleMarker);

    if (tripController.tripStatus.value == EnumTripStatus.CUSTOMERSEARCHING) {
      if (tripController.endLocation.value != null) {
        markers.add(
            Marker(width: 35, height: 35, point: tripController.getStartLatLng(), builder: (ctx) => startMarkerDesign));
        markers.add(
            Marker(width: 35, height: 35, point: tripController.getEndLatLng(), builder: (ctx) => arrivalMarkerDesign));
        animationCenterPolyline(tripController.getStartLatLng(), tripController.getEndLatLng());
      } else if (mapReady.value) {
        animationCenterPosition(tripController.getStartLatLng());
      }
      if (markers.isEmpty) markers.add(startMarker);
    }

    if (tripController.tripStatus.value == EnumTripStatus.MATCHING) {
      markers.add(startMarker);
      if (mapReady.value) {
        animationCenterPosition(tripController.getStartLatLng());
      } else {
        once(mapReady, (res) => animationCenterPosition(tripController.getStartLatLng()));
      }
    }

    if (tripController.tripStatus.value == EnumTripStatus.PICKINGUPCUSTOMER) {
      markers.add(Marker(
        width: 45,
        point: tripController.getStartLatLng(),
        builder: (ctx) => Container(
          alignment: Alignment.center,
          decoration:
              BoxDecoration(color: ColorConstant.PRIMARY, borderRadius: const BorderRadius.all(Radius.circular(12))),
          child: Text('내위치', style: CustomTextStyle.txtCaption2(color: ColorConstant.WHITE)),
        ),
      ));
      if (tripController.driverLocation.value != null) {
        markers.add(Marker(
          width: 45,
          point: tripController.driverLocation.value!,
          builder: (ctx) => Container(
            alignment: Alignment.center,
            decoration:
                BoxDecoration(color: ColorConstant.PRIMARY, borderRadius: const BorderRadius.all(Radius.circular(12))),
            child: Text('기사님', style: CustomTextStyle.txtCaption2(color: ColorConstant.WHITE)),
          ),
        ));
        if (mapReady.value) {
          animationCenterPolyline(tripController.getStartLatLng(), tripController.driverLocation.value!);
        } else {
          once(mapReady,
              (res) => animationCenterPolyline(tripController.getStartLatLng(), tripController.driverLocation.value!));
        }
      }
    }

    return markers;
  }

  List<Polyline> getPolylines() {
    var polylines = <Polyline>[];
    if (tripController.tripStatus.value == EnumTripStatus.MATCHING) return polylines;

    if (tripController.estimatedRoute.value != null) {
      polylines.add(
        Polyline(
          points: tripController.getRoute(),
          strokeWidth: 3,
          color: ColorConstant.BLACK1,
        ),
      );
    }

    return polylines;
  }

  void _animatedMapMove(LatLng destLocation, double destZoom) {
    // Create some tweens. These serve to split up the transition from one location to another.
    // In our case, we want to split the transition be<tween> our current map center and the destination.
    final latTween = Tween<double>(begin: mapController.center.latitude, end: destLocation.latitude);
    final lngTween = Tween<double>(begin: mapController.center.longitude, end: destLocation.longitude);
    final zoomTween = Tween<double>(begin: mapController.zoom, end: destZoom);

    // Create a animation controller that has a duration and a TickerProvider.
    final controller = AnimationController(duration: const Duration(milliseconds: 500), vsync: this);
    // The animation determines what path the animation will take. You can try different Curves values, although I found
    // fastOutSlowIn to be my favorite.
    final Animation<double> animation = CurvedAnimation(parent: controller, curve: Curves.fastOutSlowIn);

    controller.addListener(() {
      mapController.move(
          LatLng(latTween.evaluate(animation), lngTween.evaluate(animation)), zoomTween.evaluate(animation));
    });

    animation.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        controller.dispose();
      } else if (status == AnimationStatus.dismissed) {
        controller.dispose();
      }
    });

    controller.forward();
  }

  void animationCenterPosition(LatLng ll) {
    _animatedMapMove(ll, MAPZOOM);
  }

  void animationCenterPolyline(LatLng start, LatLng end) {
    final bounds = LatLngBounds.fromPoints([start, end]);
    var centerZoom = mapController.centerZoomFitBounds(bounds);
    _animatedMapMove(centerZoom.center, centerZoom.zoom - 0.5);
  }

  /// Builds the home page widget on the given build [context]
  @override
  Widget build(BuildContext context) {
    var findFareColumn = Column(
      children: [
        Obx(
          () => tripController.isTripSupported()
              ? Column(
                  children: [
                    CustomSVGContainer(
                      svg: tripController.cars[0],
                      text: 'home_small_car'.tr,
                      amount: tripController.smallTaxiFee.value,
                      fillColor: tripController.enumTaxiSize.value == 1 ? ColorConstant.YELLOW : null,
                      borderColor: tripController.enumTaxiSize.value == 1 ? ColorConstant.PRIMARY : null,
                      onTap: () => tripController.enumTaxiSize.value = 1,
                    ),
                    const SizedBox(height: 10),
                    CustomSVGContainer(
                      svg: tripController.cars[1],
                      text: 'home_large_car'.tr,
                      amount: tripController.largeTaxiFee.value,
                      fillColor: tripController.enumTaxiSize.value == 2 ? ColorConstant.YELLOW : null,
                      borderColor: tripController.enumTaxiSize.value == 2 ? ColorConstant.PRIMARY : null,
                      onTap: () => tripController.enumTaxiSize.value = 2,
                    ),
                  ],
                )
              : Container(
                  width: double.infinity,
                  padding: getPadding(left: 24, top: 14, right: 24, bottom: 14),
                  decoration: BoxDecoration(
                    color: ColorConstant.WHITE1,
                    border: Border.all(color: ColorConstant.RED),
                    borderRadius: BorderRadius.circular(
                      getHorizontalSize(24.00),
                    ),
                  ),
                  child: Text(
                    "location_support".tr,
                    style: CustomTextStyle.txtBody1(color: ColorConstant.BLACK1, height: 1.7, weight: FontWeight.w400),
                  )),
        ),
        const Divider(),
        IntrinsicHeight(
          child: Row(
            children: [
              Expanded(
                child: CustomTextButton(
                  onPressed: () => Get.toNamed(PAYMENTSELECT),
                  child: Row(
                    children: [
                      Icon(IconConstant.CreditCard, color: ColorConstant.BLACK1),
                      const SizedBox(width: 10),
                      Text('home_payment'.tr, style: CustomTextStyle.txtBody1()),
                      const SizedBox(width: 5),
                      Icon(IconConstant.ArrowForward, size: 16, color: ColorConstant.BLACK1)
                    ],
                  ),
                ),
              ),
              Padding(
                padding: getPadding(right: 12),
                child: Obx(
                  () => Text(tripController.getPaymentMethodText(),
                      style: CustomTextStyle.txtBody1(color: ColorConstant.BLACK3)),
                ),
              ),
            ],
          ),
        ),
        Obx(
          () => CustomTap(
            color: tripController.isTripSupported()
                ? customerController.getIsDefaultCardExist()
                    ? ColorConstant.PRIMARY
                    : ColorConstant.GREY2
                : ColorConstant.GREY2,
            onTap: () async => tripController.isTripSupported()
                ? customerController.getIsDefaultCardExist()
                    ? await tripController.confirmTrip()
                    : null
                : null,
            child: Text("home_find_button".tr, style: CustomTextStyle.txtBody3(color: ColorConstant.WHITE)),
          ),
        ),
      ],
    );
    var settingColumn = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("home_where_are_you_going".tr, style: CustomTextStyle.txtTitle1()),
        const SizedBox(height: 20),

        // from location input
        Obx(
          () => CustomTextFormField(
            controller: tripController.startLocationController.value,
            text: 'home_set_start'.tr,
            validate: validateText,
            onChanged: (text) => tripController.setError(""),
            readOnly: true,
            onTap: () {
              tripController.setFocusStart();
              Get.toNamed(TRIPSETTING);
            },
            suffixIcon: IconButton(
              icon: Icon(IconConstant.MyLocation),
              onPressed: () async {
                tripController.isLoading.value = true;
                await locationController.setCurrentLocation();
                await tripController.setStartWithLocation(locationController.currentLocation.value!);
                // startFocusNode.unfocus();
                tripController.isLoading.value = false;
              },
            ),
          ),
        ),

        //padding
        const SizedBox(height: 10),

        //destination input
        Obx(
          () => CustomTextFormField(
            controller: tripController.endLocationController.value,
            text: 'home_set_end'.tr,
            validate: validatePassword,
            onChanged: (text) => setState(
              () => tripController.setError(""),
            ),
            readOnly: true,
            onTap: () {
              tripController.setFocusEnd();
              Get.toNamed(TRIPSETTING);
            },
            suffixIcon: IconButton(
              icon: Icon(IconConstant.MyLocation),
              onPressed: () async {
                tripController.isLoading.value = true;
                await locationController.setCurrentLocation();
                await tripController.setEndWithLocation(locationController.currentLocation.value!);
                // startFocusNode.unfocus();
                var isSuccess = await tripController.makeNewTrip();
                if (isSuccess) {
                  await tripController.setEstimatedRoute(
                      tripController.getStartLatLng(), tripController.getEndLatLng());
                }
                tripController.disposeSelection();
                tripController.isLoading.value = false;
              },
            ),
          ),
        ),

        //saved location icons
        Row(
          children: [
            //home icon - onclick, set src:current, dst:home_location
            CustomSavedLocation(
              icon: Icon(IconConstant.Home, color: ColorConstant.PRIMARY),
              text: "home".tr,
              onPressed: () async {
                if (customerController.customer.value!.getHome() != null) {
                  await tripController.setEndWithLocation(customerController.customer.value!.getHome());

                  tripController.isLoading.value = true;
                  var isSuccess = await tripController.makeNewTrip();
                  if (isSuccess) {
                    await tripController.setEstimatedRoute(
                        tripController.getStartLatLng(), tripController.getEndLatLng());
                  }
                  tripController.disposeSelection();
                  tripController.isLoading.value = false;
                } else {
                  Get.toNamed(SAVEDLOCATIONS);
                }
              },
            ),

            //work icon - onclick, set src:current, dst:work_location
            CustomSavedLocation(
              icon: Icon(IconConstant.Work, color: ColorConstant.PRIMARY),
              text: "company".tr,
              onPressed: () async {
                if (customerController.customer.value!.getWork() != null) {
                  await tripController.setEndWithLocation(customerController.customer.value!.getWork());

                  tripController.isLoading.value = true;
                  var isSuccess = await tripController.makeNewTrip();
                  if (isSuccess) {
                    await tripController.setEstimatedRoute(
                        tripController.getStartLatLng(), tripController.getEndLatLng());
                  }
                  tripController.disposeSelection();
                  tripController.isLoading.value = false;
                } else {
                  Get.toNamed(SAVEDLOCATIONS);
                }
              },
            ),
            CustomSavedLocation(
              icon: Icon(IconConstant.Star, color: ColorConstant.PRIMARY),
              text: "mylocation".tr,
              onPressed: () => Get.toNamed(SAVEDLOCATIONS),
            ),

            //add an icon to add more (saved locations) - maybe not for mvp
          ],
        ),
      ],
    );
    var matchingColumn = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Obx(
              () => Padding(
                padding: getPadding(),
                child: SvgPicture.asset(
                  tripController.cars[tripController.enumTaxiSize.value - 1],
                  fit: BoxFit.contain,
                ),
              ),
            ),
            const SizedBox(width: 10),
            // Obx(
            //   () => Text('home_estimated_time'.tr + tripController.getDurationString(),
            //       style: CustomTextStyle.txtCaption2(color: ColorConstant.BLACK3)),
            // ),
          ],
        ),
        const SizedBox(height: 10),
        Text('home_finding_driver'.tr, style: CustomTextStyle.txtTitle1()),
        const SizedBox(height: 5),
        SizedBox(
          height: 90,
          child: Container(
            alignment: Alignment.topRight,
            child: FixedTimeline.tileBuilder(
              builder: TimelineTileBuilder.connected(
                contentsAlign: ContentsAlign.basic,
                contentsBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                      index == 0 ? tripController.startLocation.value!.name : tripController.endLocation.value!.name,
                      style: CustomTextStyle.txtBody1()),
                ),
                indicatorBuilder: (context, index) => index == 0
                    ? OutlinedDotIndicator(color: ColorConstant.PRIMARY)
                    : DotIndicator(color: ColorConstant.PRIMARY),
                connectorBuilder: (context, index, type) => DashedLineConnector(color: ColorConstant.PRIMARY),
                nodePositionBuilder: (context, index) => 0,
                itemExtent: 40.0,
                itemCount: 2,
              ),
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text('home_payment'.tr, style: CustomTextStyle.txtCaption2(color: ColorConstant.BLACK1)),
                const SizedBox(
                  height: 20,
                  child: VerticalDivider(thickness: 1),
                ),
                Obx(
                  () => SizedBox(
                    width: 150,
                    child: Text(
                      tripController.getPaymentMethodText(),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      softWrap: true,
                      style: CustomTextStyle.txtCaption2(color: ColorConstant.BLACK1),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: getPadding(all: 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text('home_payment_amount'.tr, style: CustomTextStyle.txtCaption2(color: ColorConstant.BLACK3)),
                  const SizedBox(
                    height: 20,
                    child: VerticalDivider(thickness: 1),
                  ),
                  Obx(
                    () => Text(
                      tripController.enumTaxiSize.value == 1
                          ? tripController.smallTaxiFee.value
                          : tripController.largeTaxiFee.value,
                      style: CustomTextStyle.txtTitle2(color: ColorConstant.BLACK1),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
    var waitingColumn = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('home_driver_coming'.tr, style: CustomTextStyle.txtTitle1(color: ColorConstant.BLACK1)),
        Obx(
          () => tripController.driver.value != null
              ? CustomDriverCard(
                  licensePlate: tripController.driver.value!.licensePlate,
                  carAndColor: '${tripController.driver.value!.carModel} ${tripController.driver.value!.carColor}',
                  companyName: tripController.driver.value!.companyName,
                  driverName: tripController.driver.value!.driverName,
                  phoneNumber: tripController.driver.value!.phoneNumber,
                  photo: 'photo',
                  isFull: false,
                )
              : const Center(),
        ),
        Obx(
          () => CustomAlert(
            bgColor: ColorConstant.YELLOW,
            color: ColorConstant.PRIMARY,
            icon: IconConstant.Clock,
            text: '${'home_minutes_approximate'.tr} ${tripController.getDurationString()} ${'home_minutes_left'.tr}',
            visible: true,
          ),
        ),
      ],
    );

    return Stack(
      children: [
        Scaffold(
          key: scaffoldKey,
          backgroundColor: ColorConstant.WHITE,

          // hidden drawer component; hidden until hamburger button clicked
          drawer: Drawer(
            child: ListView(
              children: [
                SizedBox(
                  height: 100,
                  child: DrawerHeader(
                    margin: null,
                    //padding: getPadding(all: 0),
                    //decoration: BoxDecoration(color: Colors.blue),
                    child: Obx(
                      () => Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(customerController.customer.value!.fullname!,
                              style: CustomTextStyle.txtTitle1(color: ColorConstant.BLACK1)),
                          const SizedBox(height: 10),
                          Text(customerController.customer.value!.phoneNumber!,
                              style: CustomTextStyle.txtBody1(color: ColorConstant.BLACK3)),
                        ],
                      ),
                    ),
                  ),
                ),
                for (var item in menuItemsOne)
                  ListTile(
                    title: Text(item[0], style: CustomTextStyle.txtBody3(color: ColorConstant.BLACK1)),
                    onTap: () {
                      closeDrawer();
                      Get.toNamed(item[1]);
                    },
                  ),
                const Divider(),
                for (var item in menuItemsTwo)
                  ListTile(
                    title: Text(item[0], style: CustomTextStyle.txtBody3(color: ColorConstant.BLACK3)),
                    onTap: () {
                      closeDrawer();
                      Get.toNamed(item[1]);
                    },
                  ),
              ],
            ),
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.startTop,
          floatingActionButton: Obx(
            () => tripController.tripStatus.value != EnumTripStatus.GOINGTODEST
                ? FloatingActionButton(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    onPressed: () {},
                    child: Container(
                      decoration: BoxDecoration(color: ColorConstant.WHITE, borderRadius: BorderRadius.circular(25)),
                      child: IconButton(
                        icon: Obx(
                          () => Icon(
                            tripController.isTripSet() ? IconConstant.ArrowBack : IconConstant.Menu,
                            color: ColorConstant.BLACK,
                          ),
                        ),
                        onPressed: floatingActionButtonClick,
                      ),
                    ),
                  )
                : const Center(),
          ),

          // main container; map and input menu
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              //Map
              Expanded(
                flex: 1,
                child: Obx(
                  () => locationController.locationStatus.value == EnumLocationControllerStatus.Success
                      ? Stack(
                          children: [
                            FlutterMap(
                              mapController: mapController,
                              options: MapOptions(
                                center: locationController.getCurrentLocation(),
                                zoom: MAPZOOM,
                                onMapReady: () => setState(() {
                                  mapReady(true);
                                }),
                              ),
                              children: [
                                TileLayer(urlTemplate: '$TILE?$TILEAPI'),
                                PolylineLayer(polylines: getPolylines()),
                                MarkerLayer(markers: getFlutterMarkers()),
                              ],
                            ),
                            tripController.tripStatus.value == EnumTripStatus.MATCHING
                                ? OverlayRipple.show(context)
                                : const Center(),
                          ],
                        )
                      : const Center(),
                ),
              ),

              //input menu
              IntrinsicHeight(
                child: Container(
                  width: SIZE.width,
                  padding: getPadding(left: 16, top: 24, right: 16, bottom: 32),
                  decoration: BoxDecoration(
                    color: ColorConstant.WHITE,
                    borderRadius: const BorderRadiusDirectional.vertical(top: Radius.circular(25.0)),
                    boxShadow: [
                      BoxShadow(
                        color: ColorConstant.BLACK1.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, -4),
                      )
                    ],
                  ),
                  child: Obx(
                    () => tripController.isTripSet()
                        ? tripController.tripStatus.value == EnumTripStatus.CUSTOMERSEARCHING
                            ? findFareColumn
                            : tripController.tripStatus.value == EnumTripStatus.MATCHING
                                ? matchingColumn
                                : tripController.tripStatus.value == EnumTripStatus.PICKINGUPCUSTOMER
                                    ? waitingColumn
                                    : const Center()
                        : settingColumn,
                  ),
                ),
              )
            ],
          ),
        ),

        Obx(
          () => tripController.tripStatus.value == EnumTripStatus.PICKINGUPCUSTOMER
              ? Align(
                  alignment: Alignment.topRight,
                  child: Padding(
                    padding: getPadding(top: 24, right: 12),
                    child: Container(
                      decoration: BoxDecoration(color: ColorConstant.WHITE1, borderRadius: BorderRadius.circular(25)),
                      child: TextButton.icon(
                        onPressed: () {
                          customCancelDialog(
                            okayClick: () async {
                              EmailService.sendEmailToHanin(
                                  message: tripController.complaintController.text,
                                  screen: "Refund",
                                  tripID: tripController.tripID.value);
                              Get.back();
                            }, //Send to API
                            title: 'trip_refund'.tr,
                            contentText: 'trip_refund_body'.tr,
                            cancelText: 'trip_report_close'.tr,
                            okayText: 'trip_report'.tr,
                            isContent: true,
                            hintText: 'trip_refund_hint'.tr,
                            controller: tripController.complaintController,
                          );
                        },
                        icon: Icon(IconConstant.CarReport, color: ColorConstant.BLACK3),
                        label: Text("trip_refund".tr, style: CustomTextStyle.txtCaption2(color: ColorConstant.BLACK3)),
                      ),
                    ),
                  ),
                )
              : const Center(),
        ),

        // Loading dialog
        Obx(
          () {
            if (tripController.isLoading.value) {
              return CustomLoadingDialog();
            } else {
              return const Center();
            }
          },
        ),
      ],
    );
  }
}

class OverlayRipple {
  static Widget show(BuildContext context) {
    SpinKitRipple spinkit = SpinKitRipple(
      color: ColorConstant.WHITE,
      size: 300.0,
      borderWidth: 40,
      duration: const Duration(milliseconds: 2500),
    );

    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(color: ColorConstant.BLACK.withOpacity(0.5)),
      child: spinkit,
    );
  }
}
