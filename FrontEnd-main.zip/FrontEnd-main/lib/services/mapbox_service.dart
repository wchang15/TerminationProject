import 'dart:convert';

import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:tuple/tuple.dart';

import '../models/enum_type.dart';
import '../models/user_location.dart';
import '../utils/constants.dart';

// Not being used yet. Could use for cheaper route call
class MapBoxService {
  static Future<Tuple2<List<LatLng>?, int?>> getDirection(LatLng from, LatLng to) async {
    List<LatLng>? list;
    int? duration;

    try {
      var url = Uri.parse(
          'https://api.mapbox.com/directions/v5/mapbox/driving/${getLatLngString(from, to)}?alternatives=false&geometries=geojson&overview=simplified&steps=false&access_token=$MAPBOXAPI');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var res = jsonDecode(response.body);
        duration = res["routes"][0]["duration"].toDouble().round();
        list = getPoints(res["routes"][0]["geometry"]["coordinates"]);
      }
    } catch (e) {
      print('MapBoxService.getDirection');
      print(e);
    }
    return Tuple2(list, duration);
  }

  static Future<List<UserLocation>> getAutoComplete(String address) async {
    List<UserLocation> list = <UserLocation>[];

    try {
      var url = Uri.parse(
          //'https://api.mapbox.com/geocoding/v5/mapbox.places/${address}.json?proximity=ip&types=address,poi&access_token=$MAPBOXAPI');
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${address}&types=geocode|establishment&key=$GOOGLE_API_KEY');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var res = jsonDecode(response.body);
        list = getUserLocations(res["predictions"]);
      }
    } catch (e) {
      print('MapBoxService.getAutoComplete');
      print(e);
    }
    return list;
  }

  static Future<UserLocation?> getReverseGeocode(double latitude, double longitude) async {
    try {
      var url = Uri.parse(
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=$GOOGLE_API_KEY',
      );
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var res = jsonDecode(response.body);
        var address = res["results"][0]["formatted_address"];
        var list = await getAutoComplete(address);
        return list[0];
      }
    } catch (e) {
      print('MapBoxService.getReverseGeocode');
      print(e);
    }
    return null;
  }

  static String getLatLngString(LatLng from, LatLng to) {
    return '${from.longitude},${from.latitude};${to.longitude},${to.latitude}';
  }

  static List<LatLng> getPoints(List<dynamic> encoded) {
    final points = <LatLng>[];

    encoded.forEach((element) {
      points.add(LatLng(element[1].toDouble(), element[0].toDouble()));
    });

    return points;
  }

  static List<UserLocation> getUserLocations(List<dynamic> encoded) {
    final userLocations = <UserLocation>[];

    encoded.forEach((element) {
      userLocations.add(UserLocation(
        address: element["structured_formatting"]["secondary_text"],
        name: element["structured_formatting"]["main_text"],
        latitude: 0,
        longitude: 0,
        locationType: getLocationType(element["types"]),
      ));
    });

    return userLocations;
  }

  static EnumLocationType getLocationType(List<dynamic> categories) {
    for (int i = 0; i < categories.length; i++) categories[i] = categories[i].toLowerCase();
    if (categories.contains('airport'))
      return EnumLocationType.AIRPORT;
    else if (categories.contains('restaurant'))
      return EnumLocationType.RESTAURANT;
    else if (categories.contains('store'))
      return EnumLocationType.STORE;
    else if (categories.contains('park'))
      return EnumLocationType.PARK;
    else if (categories.contains('school'))
      return EnumLocationType.SCHOOL;
    else if (categories.contains('hospital'))
      return EnumLocationType.HOSPITAL;
    else
      return EnumLocationType.OTHER;
  }
}
