import 'dart:convert';

import 'package:get/get.dart';
import 'package:signalr_netcore/ihub_protocol.dart';
import 'package:signalr_netcore/signalr_client.dart';

import '../controllers/customer_controller.dart';
import '../controllers/trip_controller.dart';
import '../models/trip.dart';
import '../utils/constants.dart';
import '../utils/secure_storage.dart';
import 'package:latlong2/latlong.dart';

class HubService {
  // Creates the connection by using the HubConnectionBuilder.

  static HubConnection hubConnection = HubConnectionBuilder()
      .withUrl(HUB_ADDRESS)
      //, options: HttpConnectionOptions(accessTokenFactory: () async => await StorageService.readSecureData(JWT);))
      //transportType: HttpTransportType.WebSockets, options: HttpConnectionOptions(skipNegotiation: true))
      .withAutomaticReconnect(
          retryDelays: [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]).build();

  static Future initSignalR() async {
    if (isConnected()) return;
    TripController tripController = Get.find<TripController>();
    hubConnection.onclose(({error}) => print(error));

    hubConnection.on(HUBMATCH, (params) async {
      await tripController.updateStatus(int.parse(params![0].toString()));
    });
    hubConnection.on(HUBUPDATEDRIVERLOCATION, (params) async {
      var jsonString = jsonEncode(params![1]);
      var temp = json.decode(jsonString);
      var loc = LatLng(temp['latitude']?.toDouble(), temp['longitude']?.toDouble());
      await tripController.setDriverLocation(loc);
    });
    hubConnection.on(HUBTRIPSTART, (params) async {
      await tripController.updateStatus(int.parse(params![0].toString()));
    });
    hubConnection.on(HUBTRIPCOMPLETE, (params) async {
      await tripController.updateStatus(int.parse(params![0].toString()));
    });
    hubConnection.on(HUBDRIVERCANCEL, (params) async {
      await tripController.updateStatus(int.parse(params![0].toString()));
    });

    hubConnection.onreconnected(({connectionId}) => addToGroup());

    await hubConnection.start();

    addToGroup();
  }

  static void addToGroup() {
    CustomerController customerController = Get.find<CustomerController>();
    hubConnection.invoke('AddToGroup', args: ['customer${customerController.customer.value!.customerId}']);
  }

  static bool isConnected() {
    return hubConnection.connectionId != null;
  }
}
