// component
import HomeTwoToneIcon from '@mui/icons-material/HomeTwoTone';
import LocalTaxiTwoToneIcon from '@mui/icons-material/LocalTaxiTwoTone';
import MapIcon from '@mui/icons-material/Map';
import SettingsIcon from '@mui/icons-material/Settings';
import EmojiPeopleIcon from '@mui/icons-material/EmojiPeople';
import SvgColor from '../../../components/svg-color';

// ----------------------------------------------------------------------

const icon = (name) => <SvgColor src={`/assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />;

const navConfig = [
  {
    title: '홈페이지',
    path: '/dashboard/app',
    icon: <HomeTwoToneIcon />,
  },
  {
    title: '기사님',
    path: '/dashboard/drivers',
    icon: icon('ic_user'),
  },

  {
    title: '택시',
    path: '/dashboard/taxi',
    icon: <LocalTaxiTwoToneIcon />,
  },
  {
    title: '리포트',
    path: '/dashboard/reports',
    icon: icon('ic_analytics'),
  },
  {
    title: '지도',
    path: '/dashboard/map',
    icon: <MapIcon />,
  },
  {
    title: '손님',
    path: '/dashboard/customer',
    icon: <EmojiPeopleIcon />,
  },
  {
    title: '설정',
    path: '/dashboard/maintenance',
    icon: <SettingsIcon />,
  },
];

export default navConfig;
