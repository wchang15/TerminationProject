
export const HUBADDRESS = 'http://localhost/Taxi';
export const APIADDRESS =  'https://www.haninapi.com/api';
// export const APIADDRESS = 'http://localhost/api';
// 'http://localhost/api';


export const COMPANYTRIP = 'companytrip';
export const COMPANYCANCEL = 'companycancel';
export const MATCH = 'match';
export const UPDATEDRIVERLOCATION = 'updatedriverlocation';
export const TRIPSTART = 'tripstart';
export const TRIPCOMPLETE = 'tripcomplete';
export const DRIVERCANCEL = 'drivercancel';

// export const GOOGLEAPIKEY = 'AIzaSyDKaH4K69Vsy_9DVNr2Sw36V_xY_ysdEVU';

export const TILE = 'https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png';
export const TILEAPI = 'api_key=3331bf0f-d10b-4010-beb8-a4fc8e1e68d4';
