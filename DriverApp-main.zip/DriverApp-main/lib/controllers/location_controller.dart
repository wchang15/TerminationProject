import 'dart:async';
import 'dart:isolate';
import 'dart:math';
import 'dart:ui';
import 'package:awesome_notifications/awesome_notifications.dart';
// import 'package:background_locator_2/background_locator.dart';
// import 'package:background_locator_2/settings/android_settings.dart';
// import 'package:background_locator_2/settings/ios_settings.dart';
// import 'package:background_locator_2/settings/locator_settings.dart' as backloc;
// import 'package:background_locator_2/settings/android_settings.dart' as android;
import 'package:driverapp/controllers/trip_controller.dart';
import 'package:driverapp/utils/size.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';

//google maps/geo service imports
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:geocoding/geocoding.dart';
import 'package:tuple/tuple.dart';
import 'package:latlong2/latlong.dart';

//models and meta imports
import '../models/user_location.dart';
import '../services/location_handler.dart';
import '../services/location_service.dart';
import '../services/trip_service.dart';
import '../utils/constants.dart';

enum EnumLocationControllerStatus { Loading, Success, Error }

/// Controls the functionality related to a user's location
class LocationController extends GetxController {
  final locationStatus = EnumLocationControllerStatus.Loading.obs;
  final isLoading = false.obs;
  final currentLocation = (null as LatLng?).obs;

  bool errorDialog = false;

  ReceivePort port = ReceivePort();

  Timer? locationTimer;

  //final currentLocation = (null as UserLocation?).obs;

  ////////// Getters //////////

  /// returns a formatted street address of the current user's current location
  // String getCurrentAddress() => currentLocation.value?.address ?? "";

  // /// returns a latitude and longitude point of the current user's current location
  // LatLng getCurrentLocation() {
  //   if (currentLocation.value == null) return LatLng(42.8243, -73.9096);
  //   return LatLng(currentLocation.value!.latitude, currentLocation.value!.longitude);
  // }

  ////////// Setters //////////s
  ///
  ///Get Coordinates (Not being used)
  Future<void> getCoordinates(UserLocation userLocation) async {
    var coordinates = await locationFromAddress("${userLocation.name}, ${userLocation.address}");
    userLocation.latitude = coordinates[0].latitude;
    userLocation.longitude = coordinates[0].longitude;
  }

  /// Attempts to retrieve the user's current location and sets location status
  Future<void> setCurrentLocation() async {
    // try {
    //   await fetchCurrentLocation();
    //   locationStatus(EnumLocationControllerStatus.Success);
    // } catch (e) {
    //   locationStatus(EnumLocationControllerStatus.Error);
    // }

    await fetchCurrentLocation();

    locationTimer = Timer.periodic(const Duration(seconds: STATUSUPDATE), (Timer t) async {
      await fetchCurrentLocation();
    });

    // if (IsolateNameServer.lookupPortByName(LocationServiceRepository.isolateName) != null) {
    //   IsolateNameServer.removePortNameMapping(LocationServiceRepository.isolateName);
    // }

    // IsolateNameServer.registerPortWithName(port.sendPort, LocationServiceRepository.isolateName);

    // port.listen(
    //   (dynamic data) async {
    //     print("background listen $data");
    //     await updateLocation(data);
    //     if (data != null) sendNotification("Location Updated", data.toString());
    //   },
    // );

    // await initPlatformState();

    // if (await checkLocationPermission()) {
    //   await startLocator();
    // }
  }

  ////////// Helper //////////

  /// Fetches a user's current location
  Future<void> fetchCurrentLocation() async {
    try {
      Position? position;
      bool isLastKnown = false;

      // validate service is enabled and location services are set
      //if (await checkLocationPermission() && await checkBatteryPermission()) {
      if (await checkLocationPermission()) {
        errorDialog = false;
        try {
          position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.best, timeLimit: const Duration(seconds: 30));
        } catch (err) {
          print("fetch Current Location $err");
          isLastKnown = true;
          position = await Geolocator.getLastKnownPosition();
        }

        print(
            'isLastKnown: $isLastKnown : location updated ${position!.latitude} ${position.longitude} ${DateTime.now().toString()}');

        if (currentLocation.value != null &&
            currentLocation.value!.latitude == position.latitude &&
            currentLocation.value!.longitude == position.longitude) return;
        LatLng ll = LatLng(position.latitude, position.longitude);
        currentLocation(ll);
        await TripService.updateQueueLocation(ll);
      } else {
        if (!errorDialog) {
          errorDialog = true;
          Get.defaultDialog(
            title: "location_permission".tr,
            middleText: "location_permission_description".tr,
            confirm: TextButton(
              onPressed: () {
                errorDialog = false;
                openAppSettings();
                Get.back();
              },
              child: Text("appsetting".tr),
            ),
          );
        }
        throw Exception("Location Service request has been denied!");
      }
    } on TimeoutException catch (e) {
      print('location_controller.fetchCurrentLocation');
      print(e);
      //throw e;
    } catch (e) {
      print('location_controller.fetchCurrentLocation');
      print(e);
      //throw e;
    }
  }

  Future<bool> checkLocationPermission() async {
    final access = await Permission.locationAlways.status;
    switch (access) {
      case PermissionStatus.denied:
      case PermissionStatus.restricted:
        final permission = await Permission.locationWhenInUse.request();
        if (permission == PermissionStatus.granted) {
          final alwaysPermission = await Permission.locationAlways.request();
          if (alwaysPermission == PermissionStatus.granted) {
            return true;
          } else {
            return false;
          }
        } else {
          return false;
        }
      case PermissionStatus.granted:
        return true;
      default:
        return false;
    }
  }

  // Future<bool> checkBatteryPermission() async {
  //   final access = await Permission.ignoreBatteryOptimizations.status;
  //   switch (access) {
  //     case PermissionStatus.denied:
  //     case PermissionStatus.restricted:
  //       final permission = await Permission.ignoreBatteryOptimizations.request();
  //       if (permission == PermissionStatus.granted) {
  //         return true;
  //       } else {
  //         return false;
  //       }
  //     case PermissionStatus.granted:
  //       return true;
  //     default:
  //       final permission = await Permission.ignoreBatteryOptimizations.request();
  //       if (permission == PermissionStatus.granted) {
  //         return true;
  //       } else {
  //         return false;
  //       }
  //   }
  // }

  Future<void> updateLocation(dynamic data) async {
    if (data != null) {
      double latitude = data["latitude"];
      double longitude = data["longitude"];
      LatLng ll = LatLng(latitude, longitude);
      currentLocation(ll);
      await TripService.updateQueueLocation(ll);

      var status = await TripService.getQueueStatus();
      if (status.item2 != null) {
        if (status.item2 == EnumTripStatus.CUSTOMERCANCELED || status.item2 == EnumTripStatus.COMPANYCANCELED) {
          sendNotification("Customer Canceled the Trip", "Please take action to get matched with another customer.");
        }
      }
    }
  }

  // Future<void> initPlatformState() async {
  //   await BackgroundLocator.initialize();
  //   print('Initialization background locator done');
  //   await BackgroundLocator.isServiceRunning();
  // }

  // Future<void> startLocator() async {
  //   Map<String, dynamic> data = {'countInit': 1};
  //   if (await BackgroundLocator.isServiceRunning()) await BackgroundLocator.unRegisterLocationUpdate();
  //   return await BackgroundLocator.registerLocationUpdate(
  //     LocationCallbackHandler.callback,
  //     initCallback: LocationCallbackHandler.initCallback,
  //     initDataCallback: data,
  //     disposeCallback: LocationCallbackHandler.disposeCallback,
  //     iosSettings: const IOSSettings(
  //         accuracy: backloc.LocationAccuracy.NAVIGATION, distanceFilter: 800, stopWithTerminate: true), // half mile
  //     autoStop: false,
  //     androidSettings: const android.AndroidSettings(
  //       accuracy: backloc.LocationAccuracy.NAVIGATION,
  //       interval: 60, // hour trying to ignore this and use distance filter for both
  //       distanceFilter: 800,
  //       client: android.LocationClient.google,
  //     ),
  //   );
  // }

  void sendNotification(String title, String body) {
    AwesomeNotifications().createNotification(
      content: NotificationContent(
          id: Random().nextInt(100),
          channelKey: "HaninTaxi_Key",
          title: title,
          body: body,
          wakeUpScreen: true,
          criticalAlert: true),
    );
  }
}
