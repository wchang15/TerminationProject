//general imports

import 'dart:async';

import 'package:driverapp/controllers/location_controller.dart';
import 'package:driverapp/controllers/trip_controller.dart';
import 'package:driverapp/services/driver_service.dart';
import 'package:get/get.dart';
import 'package:latlong2/latlong.dart';
import 'package:map_launcher/map_launcher.dart';

import '../models/driver.dart';
import '../models/user_login.dart';
import '../services/login_service.dart';
import '../utils/constants.dart';
import '../utils/secure_storage.dart';

class DriverController extends GetxController {
  final isLoading = false.obs;
  final errorResponse = "".obs;
  final driver = (null as Driver?).obs;
  final isRefreshSuccess = (null as bool?).obs;
  final map = (null as AvailableMap?).obs;

  final locationController = Get.find<LocationController>();
  final tripController = Get.find<TripController>();

  ///getter

  ///setter
  void setError(String text) => errorResponse(text);

  Future setMap(String text) async {
    var mapName = text.toLowerCase();
    var maps = await MapLauncher.installedMaps;
    AvailableMap chosen;
    try {
      chosen = maps.where((element) => element.mapName.toLowerCase() == mapName).first;
    } catch (err) {
      chosen = maps.first;
    }
    map(chosen);
  }

  Future setMapWithMap(AvailableMap avail) async {
    map(avail);
    //Save db
    var lowerMap = avail.mapName.toLowerCase();
    final res = await DriverService.updateMap(lowerMap);
    if (res == null) {
      driver.value!.make = lowerMap;
    }
  }

  ///api calls
  Future<void> login(UserLogin userLogin) async {
    isLoading(true);

    try {
      final response = await LoginService.postLoginDriver(userLogin);
      driver(response.item1);
      errorResponse(response.item2);
      await updateLanguage();
      await tripController.getStatus();
    } catch (e) {
    } finally {
      isLoading(false);
    }
  }

  Future<void> refreshToken() async {
    isLoading(true);

    try {
      //final response = await LoginService.postRefreshToken();
      var username = await StorageService.readSecureData(ID);
      var pwd = await StorageService.readSecureData(PWD);
      if (username == null || pwd == null) {
        isRefreshSuccess(false);
        isLoading(false);
        return;
      }
      UserLogin userLogin = UserLogin(username: username, password: pwd);
      final response = await LoginService.postLoginDriver(userLogin);
      driver(response.item1);
      errorResponse(response.item2);
      isRefreshSuccess(response.item1 != null);
      await updateLanguage();
    } catch (e) {
    } finally {
      isLoading(false);
    }
  }

  Future<void> logout() async {
    isLoading(true);

    try {
      await LoginService.postLogout();
      driver.value = null;
      refresh();
    } catch (e) {
    } finally {
      isLoading(false);
    }
  }

  Future<bool> enqueue() async {
    bool ret = false;

    try {
      final response = await DriverService.postDriverQueue(locationController.currentLocation.value!);
      if (response != null) return ret;
      ret = true;
      if (tripController.tripStatus.value == EnumTripStatus.NONE) {
        tripController.tripStatus(EnumTripStatus.CUSTOMERSEARCHING);
      }
    } catch (e) {
    } finally {}
    return ret;
  }

  Future updateLanguage() async {
    if (driver.value != null) {
      await Get.updateLocale(LANGUAGEMAP[driver.value!.language]);
    }
  }
}
