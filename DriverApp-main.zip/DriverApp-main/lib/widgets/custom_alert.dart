import 'package:flutter/material.dart';

import '../utils/size.dart';
import '../utils/text_styles.dart';

// creating blue (success) or red (error) alert widget
class CustomAlert extends StatelessWidget {
  CustomAlert({required this.bgColor, required this.color, required this.icon, required this.text, this.visible});

  Color bgColor;
  Color color;
  IconData icon;
  String text;
  bool? visible;

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: visible ?? true,
      child: buildAlert(),
    );
  }

  buildAlert() {
    return Container(
      margin: getMargin(left: 10, right: 10, bottom: 10),
      padding: getPadding(all: 13),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: bgColor,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 5),
          Text(text, style: CustomTextStyle.txtBody1(color: color)),
        ],
      ),
    );
  }
}
