import 'dart:convert';

import 'package:get/get.dart';
import 'package:signalr_netcore/default_reconnect_policy.dart';
import 'package:signalr_netcore/ihub_protocol.dart';
import 'package:signalr_netcore/iretry_policy.dart';
import 'package:signalr_netcore/signalr_client.dart';

import '../controllers/driver_controller.dart';
import '../controllers/trip_controller.dart';
import '../models/trip.dart';
import '../utils/constants.dart';
import '../utils/secure_storage.dart';

class HubService {
  // Creates the connection by using the HubConnectionBuilder.

  static HubConnection hubConnection = HubConnectionBuilder()
      .withUrl(HUB_ADDRESS)
      //, options: HttpConnectionOptions(accessTokenFactory: () async => await StorageService.readSecureData(JWT);))
      //transportType: HttpTransportType.WebSockets, options: HttpConnectionOptions(skipNegotiation: true))
      .withAutomaticReconnect(retryDelays: [
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000,
    1000
  ]).build();

  static Future initSignalR() async {
    if (isConnected()) return;
    TripController tripController = Get.find<TripController>();
    hubConnection.onclose(({error}) async {
      print(error);
      await hubConnection.start();
      addToGroup();
    });

    hubConnection.keepAliveIntervalInMilliseconds = 1000 * 60 * 5;
    hubConnection.serverTimeoutInMilliseconds = 1000 * 60 * 10;

    hubConnection.on(HUBMATCH, (params) async {
      if (tripController.tripStatus.value == EnumTripStatus.CUSTOMERSEARCHING) {
        var trip = tripFromJson(jsonEncode(params![1]));
        await tripController.updateStatus(trip, int.parse(params[0].toString()));
      }
    });

    hubConnection.on(HUBCUSTOMERCANCEL, (params) async {
      var tripID = int.tryParse(params![1].toString()) ?? -1;
      if (tripID == (tripController.trip.value?.tripID ?? 0)) {
        await tripController.updateStatus(null, int.parse(params![0].toString()));
      }
    });

    hubConnection.on(HUBCOMPANYCANCEL, (params) async {
      var tripID = int.tryParse(params![1].toString()) ?? -1;
      if (tripID == (tripController.trip.value?.tripID ?? 0)) {
        await tripController.updateStatus(null, int.parse(params![0].toString()));
      }
    });

    // Good
    hubConnection.on(PRICEUPDATE, (params) async {
      var tripID = int.tryParse(params![1].toString()) ?? -1;
      if (tripID == (tripController.trip.value?.tripID ?? 0)) {
        tripController.trip.update((val) => val?.tripAmount = double.parse(params![0].toString()));
      }
    });

    // Good
    hubConnection.on(NOTEUPDATE, (params) async {
      var tripID = int.tryParse(params![1].toString()) ?? -1;
      if (tripID == (tripController.trip.value?.tripID ?? 0)) {
        tripController.trip.update((val) => val?.note = params![0].toString());
      }
    });

    // Good
    hubConnection.on(ALCOHOLDRIVERMATCH, (params) async {
      var tripID = int.tryParse(params![1].toString()) ?? -1;
      if (tripID == (tripController.trip.value?.tripID ?? 0)) {
        tripController.trip.update((val) => val?.alcoholPhoneNumber = params![0].toString());
      }
    });

    hubConnection.on(TRIPSTART, (params) async {
      if (tripController.trip.value != null && tripController.trip.value!.getEnumTripType() == EnumTripType.ALCOHOL2) {
        var trip = tripFromJson(jsonEncode(params![1]));
        tripController.updateStatus(trip, int.parse(params[0].toString()));
      }
    });

    hubConnection.onreconnected(({connectionId}) {
      print("Hub Reconnected");
      addToGroup();
    });

    hubConnection.onreconnecting(({error}) {
      print("hub reconnecting $error");
    });

    await hubConnection.start();

    addToGroup();

    print("Hub Connected");
  }

  static void addToGroup() {
    DriverController driverController = Get.find<DriverController>();
    hubConnection.invoke('AddToGroup', args: ['driver${driverController.driver.value!.driverID}']);
  }

  static bool isConnected() {
    return hubConnection.connectionId != null;
  }
}
