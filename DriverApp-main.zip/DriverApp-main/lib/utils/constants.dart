// API address for IOS
//const String API_ADDRESS = 'https://localhost:7023/api/';

// API address for android
import 'dart:ui';

// Android api
const String API_ADDRESS = 'http://10.0.2.2:80/api/';
const String HUB_ADDRESS = 'http://10.0.2.2:80/Taxi';

//prod api
// const String API_ADDRESS = 'https://www.haninapi.com/api/';
// const String HUB_ADDRESS = 'https://www.haninapi.com/Taxi';

const String MAPBOXAPI = 'pk.eyJ1IjoiZGFtb242MjkiLCJhIjoiY2xlNGs3bWJsMDNzdDNvbXNvMjcydXgwcCJ9.UTcz8nfh914ihTN97aCNjA';
const String GOOGLE_API_KEY = 'AIzaSyDKaH4K69Vsy_9DVNr2Sw36V_xY_ysdEVU';

//Secure Storage
const String JWT = 'jwt';
const String REFRESH = 'refresh';
const String ID = 'id';
const String PWD = 'pwd';

//Routes
const String HOME = '/home';
const String LOGIN = '/login';
const String INITIAL = '/initial';
const String TRIP = '/trip';
const String TRIPHISTORY = '/triphistory';
const String SELECTLOCATION = '/selectlocation';

//Languages
const Locale KOREAN = Locale('ko', 'KR');
const Locale ENGLISH = Locale('en', 'US');
const Locale SPANISH = Locale('es', 'MX');
const String STRKOREAN = 'ko_KR';
const String STRENGLISH = 'en_US';
const String STRSPANISH = 'es_MX';

//This have to match API
const Map LANGUAGEMAP = {1: ENGLISH, 2: KOREAN, 3: SPANISH};

//Time
const int STATUSUPDATE = 30;
const int POLLINGTIMER = 60;
const int DEBOUNCE = 300;
const int MATCHTIMER = 15;
const int DOUBLECLICKDEBOUNCE = 200;

//Hub
const String HUBMATCH = "match";
const String HUBCUSTOMERCANCEL = "customercancel";
const String HUBCOMPANYCANCEL = "companycancel";
const String PRICEUPDATE = "priceupdate";
const String NOTEUPDATE = "noteupdate";
const String ALCOHOLDRIVERMATCH = "alcoholdrivermatch";
const String TRIPSTART = "tripstart";
